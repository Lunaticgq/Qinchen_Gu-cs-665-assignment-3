/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: FrequentCustomer.java
 */

package EmailGenerationApp;

public class FrequentCustomer extends Customer {
    public FrequentCustomer(String name, EmailTemplate emailTemplate) {
        super(name, emailTemplate);
    }

    @Override
    public String generateEmail() {
        String email = emailTemplate.getTemplate();
        return email.replace("[CUSTOMER_TYPE]", "Frequent Customer " + name)
                .replace("[MESSAGE]", "We appreciate your frequent visits. Here's a special Coupon just for you.");
    }
}
