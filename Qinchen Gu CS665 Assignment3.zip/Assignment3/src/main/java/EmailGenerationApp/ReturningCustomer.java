/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: ReturningCustomer.java
 */

package EmailGenerationApp;

public class ReturningCustomer extends Customer {
    public ReturningCustomer(String name, EmailTemplate emailTemplate) {
        super(name, emailTemplate);
    }

    @Override
    public String generateEmail() {
        String email = emailTemplate.getTemplate();
        return email.replace("[CUSTOMER_TYPE]", "Returning Customer " + name)
                .replace("[MESSAGE]", "Thank you for your continued trust in our company.");
    }
}

