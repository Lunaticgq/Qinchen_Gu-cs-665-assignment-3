/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: NewCustomer.java
 */

package EmailGenerationApp;

public class NewCustomer extends Customer {
    public NewCustomer(String name, EmailTemplate emailTemplate) {
        super(name, emailTemplate);
    }

    @Override
    public String generateEmail() {
        String email = emailTemplate.getTemplate();
        return email.replace("[CUSTOMER_TYPE]", "New Customer " + name)
                .replace("[MESSAGE]", "Welcome to our company! We hope you enjoy our services.");
    }
}
