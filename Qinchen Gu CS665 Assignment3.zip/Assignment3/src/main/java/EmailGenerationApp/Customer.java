/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: Customer.java
 */

package EmailGenerationApp;

public abstract class Customer {
    protected String name;
    protected EmailTemplate emailTemplate;

    public Customer(String name, EmailTemplate emailTemplate) {
        this.name = name;
        this.emailTemplate = emailTemplate;
    }

    public abstract String generateEmail();
}
