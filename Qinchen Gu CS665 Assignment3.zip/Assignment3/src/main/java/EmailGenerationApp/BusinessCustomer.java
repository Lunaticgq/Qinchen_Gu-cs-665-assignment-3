/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: BusinessCustomer.java
 */

package EmailGenerationApp;

public class BusinessCustomer extends Customer {
    public BusinessCustomer(String name, EmailTemplate emailTemplate) {
        super(name, emailTemplate);
    }

    @Override
    public String generateEmail() {
        String email = emailTemplate.getTemplate();
        return email.replace("[CUSTOMER_TYPE]", "Business Customer " + name)
                .replace("[MESSAGE]", "Message for Business Customer");
    }
}
