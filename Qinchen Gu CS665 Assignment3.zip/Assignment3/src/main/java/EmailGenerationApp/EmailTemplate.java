/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: EmailTemplate.java
 */

package EmailGenerationApp;

public class EmailTemplate {
    private String template = "Dear [CUSTOMER_TYPE],\n\n[MESSAGE]\n\nRegards,\nThe Company";

    public String getTemplate() {
        return template;
    }
}
